Atom NLP Challenge

Description:
The challenge is divided into 2 stages based on the difficuty. 
You are free to use whether LLM or NLP methods as long as the results look good to you.
The aim of this challenge is for you to show off all the skills and expertise you know about this area.
We will compare your results with the groudtruth we have and results matter also the procedure.

Stage 1:
	Task: Sentiment Classification for movie reviews
	Description: We have 50 movie reviews from different movies, do the sentiment classification for each one of the them and save the result to the new column
	Data: movie_reviews.xlsx
	Expected output: colums = [review_id, review, sentiment]
					rows = 50

Stage 2:
	Task: Relate the description with the review
	Description: Find out which review belongs to which description. the ratio of description/review is not fixed, some with more some with less.
	Data: movie_reviews.xlsx,movie_description.xlsx 
	Expected output: colums = [review_id, description_id]
					rows = 50
